from django.contrib import admin

# Register your models here.

from vehicleapp1.models import Vehicletype,Vehicle
admin.site.register(Vehicletype)
admin.site.register(Vehicle)