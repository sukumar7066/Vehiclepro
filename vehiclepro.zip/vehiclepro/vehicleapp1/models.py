from django.db import models
from django.core.validators import RegexValidator

an=RegexValidator(r'^[0-9a-zA-Z]*$','only alpha numeric is allowed')
# Create your models here.

from django.contrib.auth.models import AbstractUser
from django.db import models

# class User(AbstractUser):
#     is_admin2=models.BooleanField(default=False)

class Vehicletype(models.Model):
    type=models.CharField(max_length=30)
    slug = models.SlugField(max_length=250, unique=True)
    def __str__(self):
        return self.type


class Vehicle(models.Model):
    number=models.CharField(max_length=30,validators=[an])
    vehicle_type=models.ForeignKey(Vehicletype,on_delete=models.CASCADE)
    model=models.TextField()
    desc=models.TextField(null=True)
