from django.shortcuts import render
from vehicleapp1.models import Vehicletype,Vehicle
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from vehicleapp1.forms import Vehicleform
from django.contrib.auth.decorators import user_passes_test

def home(request):

    return render(request,'home.html')
@login_required
def vehicleedit(request):
    v = Vehicle.objects.all()
    return render(request,'vehicleedit.html',{'v':v})

@login_required
def vehicle(request):
    v=Vehicle.objects.all()
    return render(request,'vehicle.html',{'v':v})

def user_login(request):
    if (request.method == "POST"):
        u = request.POST['u']
        p = request.POST['p']
        user=authenticate(username=u,password=p)
        if user and user.is_superuser==True:
            login(request, user)
            return vehicleedit(request)
        if user:
            login(request,user)
            return vehicle(request)
        else:
            messages.error(request, "invalid user")
    return render(request,'userlogin.html')



def user_register(request):
    if(request.method=="POST"):
        u =request.POST['u']
        f = request.POST['f']
        l = request.POST['l']

        p = request.POST['p']
        cp = request.POST['cp']
        if(p==cp):
            u=User.objects.create_user(username=u,password=p,first_name=f,last_name=l)
            u.save()
            return home(request)
        else:
            messages.error(request,"PASSWORDS ARE NOT SAME")

    return render(request,'userreg.html')

@login_required
def user_logout(request):
    logout(request)
    return home(request)

@user_passes_test(lambda u:u.is_superuser)
@login_required
def deletevehicle(request,p):
    v = Vehicle.objects.get(id=p)
    v.delete()
    return vehicleedit(request)

@user_passes_test(lambda u:u.is_superuser)
@login_required
def editvehicle(request,p):

    v = Vehicle.objects.get(id=p)
    form = Vehicleform(instance=v)
    if (request.method == "POST"):
        form = Vehicleform(request.POST, request.FILES, instance=v)

        if form.is_valid():
            form.save()
            return vehicleedit(request)
    return render(request, 'update.html', {'form': form})



@user_passes_test(lambda u:u.is_superuser)
@login_required
def addvehicle(request):  #for creating builtin form in template and data accesing and storing
    form=Vehicleform()
    if(request.method=="POST"):
        form=Vehicleform(request.POST)

        if form.is_valid():
            form.save()
            return vehicleedit(request)
    return render(request, 'addvehicle.html',{'form':form} )

