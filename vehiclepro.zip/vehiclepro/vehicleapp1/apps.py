from django.apps import AppConfig


class Vehicleapp1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vehicleapp1'
