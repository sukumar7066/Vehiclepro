from vehicleapp1.models import Vehicletype,Vehicle
from django import forms
# for creating builtin forms in template
class Vehicleform(forms.ModelForm):
    class Meta:
        model=Vehicle
        fields="__all__"
